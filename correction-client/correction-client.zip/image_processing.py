import cv2
import numpy as np
import os

log_file = None

def log_message(message):
        log_file.write(message + "\n")

def check_for_blurriness(image, image_path):
    laplacian_var = cv2.Laplacian(image, cv2.CV_64F).var()
    print(f"Laplacian variance: {laplacian_var}")
    if laplacian_var < 2000:  # Threshold for blurriness
        print(f"{image_path}: Image is blurry.")
        return True
    return False

def check_for_thumbs(image, image_path):
    # Calculate the crop area (bottom 15% of the image)
    h, w = image.shape
    crop_start = int(0.92 * h)  # Start at 85% of the height, down to the bottom
    cropped_image = image[crop_start:h, 0:w]

    # Apply threshold to the cropped image
    threshold = cv2.threshold(cropped_image, 120, 255, cv2.THRESH_BINARY)[1]
    contours, _ = cv2.findContours(threshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    cv2.imwrite(f"books\\thumbs\\thumbs_threshold_{image_path.split('\\')[-1]}.tif", threshold)

    log_message(f'Cropped image dimensions: {cropped_image.shape}')

    image_area = cropped_image.shape[0] * cropped_image.shape[1]
    thumbs_area = 0.01 * image_area  # Threshold for thumbs area

    white_area = 0

    for cnt in contours:
        log_message(f'Contour area: {cv2.contourArea(cnt)}')
        area = cv2.contourArea(cnt)
        white_area += area

    # print(f'white area: {white_area}')

    if white_area > thumbs_area:  # Minimum size of thumbs
        print(f"{image_path.split('\\')[-2] + '\\' + image_path.split('\\')[-1]}: Thumb detected.")
        return True
    return False


def check_for_bent(image, image_path):
    # Check for bent pages by detecting straight lines
    edges = cv2.Canny(image, 50, 150, apertureSize=3)

    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100, minLineLength=100, maxLineGap=10)

    cv2.imwrite(f"books\\edges\\edges_{image_path.split('\\')[-1]}.tif", edges)

    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            if abs(y2 - y1) > abs(x2 - x1):  # More vertical than horizontal
                # print(f"{image_path}: Bent page detected.")
                return True

    return False    
            
def check_for_lightspots(image, image_path):
    light_spots = cv2.threshold(image, 250, 255, cv2.THRESH_BINARY)[1]  # Threshold for light spots
    spot_contours, _ = cv2.findContours(light_spots, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    image_area = image.shape[0] * image.shape[1]
    light_spots_area = 0.002 * image_area  # Threshold for shadow area

    cv2.imwrite(f"books\\lightspots\\lightspots_threshold_{image_path.split('\\')[-1]}.tif", light_spots)

    for cnt in spot_contours:
        area = cv2.contourArea(cnt)
        if area > light_spots_area:  # Minimum size of light spots
            print(f"{image_path.split('\\')[-2] + '\\' + image_path.split('\\')[-1]}: Light spot detected.")
            return True
        
    return False

def analyze_image(image_path):
    # Read the image
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)    
    image = cv2.resize(image, (0, 0), fx=0.25, fy=0.25)
    
    # Check for blurriness
    blurry = check_for_blurriness(image, image_path)

    # Check for thumbs and shadows
    thumbs = check_for_thumbs(image, image_path)

    # Check for bent pages by detecting straight lines
    bent = check_for_bent(image, image_path)
    
    # Check for light spots
    light_spots = check_for_lightspots(image, image_path)

    return [blurry, thumbs, bent, light_spots]

def print_seperator():
    print("-" * 100)

def analyze_folder(folder_path):
    global log_file
    i = 0
    temp = open("log.txt", "w")
    temp.write("Log file\n")
    temp.close()

    log_file = open("log.txt", "a")
    for filename in os.listdir(folder_path):
        if i < 0 or i >= 5:
            i+=1
            continue

        print(f"Analyzing {filename}")
        if filename.endswith('.tif'):
            analyze_image(os.path.join(folder_path, filename))
        print_seperator()
        i+=1

    log_file.close()
